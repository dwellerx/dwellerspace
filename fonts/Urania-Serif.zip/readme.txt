Thank you for get this typeface! 

This font was designed for texts and typographic boxes. 
If you want to donate or make contact,
please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com

Copyright 2013. Type Sailor - David Espinosa. Just for personal use.
